from django.urls import path
from . import views
urlpatterns = [
    path('',views.index,name='indexAdmin'),
    path('add_tutorials/',views.task_add_tutorials,name='task_add_tutorials'),
    path('add_data_structure/',views.task_add_data_structure,name='task_add_data_structure'),
    path('database_tutorials/',views.database_tutorials,name='database_tutorials'),
    path('database_data_structure',views.database_data_structure,name='database_data_structure'),
   
]