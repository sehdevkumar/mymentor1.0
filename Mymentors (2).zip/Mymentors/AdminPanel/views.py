from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib import messages
from home.models import *
# Create your views here.

def index(request):

	return render(request,'AdminPanel/index.html')




def database_tutorials(request):
	try:
		if request.method=="POST" and request.POST['action']=="updatePage" and request.FILES:
			name = request.POST['name']
			channel_name = request.POST['cname']
			title = request.POST['ctitle']
			profile_img  = request.FILES['cprofile']
			channel_profile = request.FILES['ccprofile']
			about = request.POST['abouts']
			subscribers = request.POST['subscribers']
			channel_link = request.POST['clink']
			intro_video = request.POST['ilink']
			if profile_img=='' or channel_profile=='':
				print("Please choose file")
			else:
				obj = Tutorials.objects.get(id=request.POST['uid'])
				obj.profile_img=profile_img
				obj.channel_profile = channel_profile
				obj.save()
				updates = Tutorials.objects.filter(id=request.POST['uid']).update(

					name=name,
					channel_name=channel_name,
					title=title,
					about=about,
					subscribers=subscribers,
					channel_link=channel_link,
					intro_video=intro_video,
					tutorial_cate=request.POST['cate']
					)
				messages.info(request,"successfully updated")
				return redirect('database_tutorials')
		elif request.method=="POST" and request.POST['action']=="updatePage":
			name = request.POST['name']
			channel_name = request.POST['cname']
			title = request.POST['ctitle']
			about = request.POST['abouts']
			subscribers = request.POST['subscribers']
			channel_link = request.POST['clink']
			intro_video = request.POST['ilink']
			updates = Tutorials.objects.filter(id=request.POST['uid']).update(

				name=name,
				channel_name=channel_name,
				title=title,
				about=about,
				subscribers=subscribers,
				channel_link=channel_link,
				intro_video=intro_video,
				tutorial_cate=request.POST['cate']
				)
			messages.info(request,"successfully updated")
			return redirect('database_tutorials')
	except Exception as e:
		messages.error(request,"Update process failed!,Please Choose Both (Profile) and (Channel Profile) If You Choosing one!, else leave both!")


	if request.method=="POST" and request.POST['action']=='edit-ts-action':
		pid = request.POST['pid']
		all_details = Tutorials.objects.filter(id=pid)
		return render(request,'AdminPanel/edit_ts.html',{"all_details":all_details})



	dt = Tutorials.objects.all()
	return render(request,'AdminPanel/database_ts.html',{"dt":dt})



def database_data_structure(request):

	return render(request,'AdminPanel/database_ds.html')




def task_add_tutorials(request):
	if request.method=='POST' and request.FILES:
		name = request.POST['name']
		channel_name = request.POST['cname']
		title = request.POST['ctitle']
		profile_img  = request.FILES['cprofile']
		channel_profile = request.FILES['ccprofile']
		about = request.POST['abouts']
		subscribers = request.POST['subscribers']
		channel_link = request.POST['clink']
		intro_video = request.POST['ilink']
		tutorial_cate = request.POST['cate']
		
		file1 = []
		file1 = str(profile_img).split('.')
		file2 = str(channel_profile).split('.')

		if file1[1] not in ['JPEG','PNG','JPG','jpeg','png','jpg'] or file2[1] not in ['JPEG','PNG','JPG','jpeg','png','jpg']:
			messages.error(request,'This file Type is not allowed ',file1[1],file2[1])
			return redirect('task_add_tutorials')

		else:
			obj = Tutorials.objects.create(
				name=name,
				channel_name=channel_name,
				title=title,
				profile_img=profile_img,
				channel_profile=channel_profile,
				about=about,
				subscribers=subscribers,
				channel_link=channel_link,
				intro_video=intro_video,
				tutorial_cate=tutorial_cate
				)

			obj.save()
			
			messages.info(request,'Tutorial Details is successfully added ')
			return redirect('task_add_tutorials')
		# print(name,channel_name,title,profile_img,channel_profile,about,subscribers,channel_link,intro_video,tutorial_cate)


	return render(request,'AdminPanel/Add_Tutorials.html')


def task_add_data_structure(request):
	try:
		if request.method=="POST" and request.FILES:
			file = request.FILES['file_ds']
			page = request.POST['page']
			cate = request.POST['cate_ds']
			f = []
			f = str(file).split('.')
			if page=='':
				messages.error(request,'Please write something in page!')
				return redirect('task_add_data_structure')
			elif cate=='Select':
				messages.error(request,'Please Select Category!')
				return redirect('task_add_data_structure')
			elif f[1] not in  ['JPEG','PNG','JPG','jpeg','png','jpg']:
				messages.error(request,"Please Choose Image file!")
				return redirect('task_add_data_structure')
			else:
				obj = DataStructue.objects.create(
					page=page,
					ds_cate=cate,
					any_pic=file
					)

				obj.save()
				messages.info(request,"successfully added")
				return redirect('task_add_data_structure')

	except Exception as e:
		print(e)
	


	return render(request,'AdminPanel/Add_Data_Structure.html')
