$(document).ready(function(){




    $("body").delegate(".edit-ts","click",function(e){

       $("#openEditContainer").addClass("active");
       var pid = $(this).attr("pid");
       $.ajax({

            url:"",
            type:"POST",
            data:{
                pid:pid,
                action:"edit-ts-action",
                csrfmiddlewaretoken:$('input[name=csrfmiddlewaretoken]').val()
            },
            success:function(response){
               
               // console.log(response);
               $("#dataset_ts").html(response);
                
            }


           });

    });



    $("body").delegate("#file_preview_ds",'change',function(e){


        var file = $(this).get(0).files[0];

        if(file){
            var reader = new FileReader();
 
            reader.onload = function(){
                 $("#previewImg3").css("display","block");
                $("#previewImg3").attr("src", reader.result);
            }
 
            reader.readAsDataURL(file);
        }
        


    });

	$("body").delegate("#Creator_profile",'change',function(e){


		var file = $(this).get(0).files[0];

        if(file){
            var reader = new FileReader();
 
            reader.onload = function(){
                $("#previewImg1").attr("src", reader.result);
            }
 
            reader.readAsDataURL(file);
        }
		


	});


	$("body").delegate("#Creator_cprofile",'change',function(e){


		var file = $(this).get(0).files[0];

        if(file){
            var reader = new FileReader();
 
            reader.onload = function(){
                $("#previewImg2").attr("src", reader.result);
            }
 
            reader.readAsDataURL(file);
        }
		


	});
	


});