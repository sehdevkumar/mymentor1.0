$(document).ready(function(e){


	$("body").delegate("#search_box","keyup",function(E){

		var text = $(this).val();

		if(text==""){
			text="";
			$("#data_box").css("display","none");
		}else{
			$.ajax({

			url:"",
			type:"POST",
			data:{
				data:text,
				action:"Search_Home",
				csrfmiddlewaretoken:$('input[name=csrfmiddlewaretoken]').val()
			},
			success:function(response){
				if(response=="Empty"){
					$("#data_box").css("display","none");
				}else{
					$("#data_box").css("display","block");
					$("#data_box").html(response);
				}
				
			}


		   });
		}
		

		


	});


});