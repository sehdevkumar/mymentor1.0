$(document).ready(function(){
	check1 = true;
   $(".data-structue").click(function(e){
   		e.preventDefault();
   		if($(".data-structue-ul").toggleClass("active")){
   			$(this).toggleClass("active");
   		
   			if(check1){
   				$(".mark1").html("&#9866");
   				check1=false;
   			}else{
   				$(".mark1").html("&#10010");
   				check1=true;
   			}
   		}

   });
   check2 = true;
    $(".data-structue2").click(function(e){
   		e.preventDefault();
   		if($(".data-structue-ul2").toggleClass("active")){
   			$(this).toggleClass("active");
   			if(check2){
   				$(".mark2").html("&#9866");
   				check2=false;
   			}else{
   				$(".mark2").html("&#10010");
   				check2=true;
   			}
   			
   		}

   });


});