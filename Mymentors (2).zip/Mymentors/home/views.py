from django.shortcuts import render,redirect
from django.http import HttpResponse
# Create your views here.
from .models import *
def index(request):
	if request.method=="POST" and request.POST['action']=='Search_Home':
		data = request.POST['data']
		if data=='':
			return HttpResponse('Empty')
		else:
			obj1 = DataStructue.objects.filter(ds_cate__icontains=data)
			obj2 = Tutorials.objects.all().filter(name__icontains=data)
			obj3 = Tutorials.objects.all().filter(title__icontains=data)
			return render(request,'home/searchData.html',{"obj1":obj1,"obj2":obj2,"obj3":obj3})
	return render(request,'home/index.html')


def url_index(request,url_str='',next_url=''):
	if request.method=="POST" and request.POST['action']=='Search_Home':
		data = request.POST['data']
		if data=='':
			return HttpResponse('Empty')
		else:
			obj1 = DataStructue.objects.filter(ds_cate__icontains=data)
			obj2 = Tutorials.objects.all().filter(name__icontains=data)
			obj3 = Tutorials.objects.all().filter(title__icontains=data)
			return render(request,'home/searchData.html',{"obj1":obj1,"obj2":obj2,"obj3":obj3})
	try:
		if next_url in ['web_dev','android','c','c_plus_plus','python','react','javascript','java','django_framework']:
			return redirect('http://127.0.0.1:8000/'+str(next_url))
		elif next_url in ['Array','Queue','Stack','LinkedList','BinaryTree','BTree']:
			return redirect('http://127.0.0.1:8000/'+str(next_url))


		fetch = Tutorials.objects.filter(tutorial_cate=url_str)
		webpages =  DataStructue.objects.filter(ds_cate=url_str)
		return render(request,"home/"+str(url_str)+".html",{"fetch":fetch,"webpages":webpages})
	except Exception as e:
		return HttpResponse('')


def about_index(request,url_str='',next_url='',pid='',ignore_url=''):
	if request.method=="POST" and request.POST['action']=='Search_Home':
		data = request.POST['data']
		if data=='':
			return HttpResponse('Empty')
		else:
			obj1 = DataStructue.objects.filter(ds_cate__icontains=data)
			obj2 = Tutorials.objects.all().filter(name__icontains=data)
			obj3 = Tutorials.objects.all().filter(title__icontains=data)
			return render(request,'home/searchData.html',{"obj1":obj1,"obj2":obj2,"obj3":obj3})
	if ignore_url in ['web_dev','android','c','c_plus_plus','python','react','javascript','java','django_framework']:
		return redirect('http://127.0.0.1:8000/'+str(ignore_url)) 
	elif ignore_url in ['Array','Queue','Stack','LinkedList','BinaryTree','BTree']:
		return redirect('http://127.0.0.1:8000/'+str(ignore_url))
	if ignore_url=='':
		all_data = Tutorials.objects.filter(id=pid)
		return render(request,'home/full_details.html',{"all_data":all_data})