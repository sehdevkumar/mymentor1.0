from django.urls import path
from . import views
urlpatterns = [
    path('',views.index,name='index'),
    path('<str:url_str>/',views.url_index),
    path('<str:url_str>/<str:next_url>/',views.url_index),
    path('<str:url_str>/<str:next_url>/<str:pid>/',views.about_index),
    path('<str:url_str>/<str:next_url>/<str:pid>/<str:ignore_url>/',views.about_index),
]