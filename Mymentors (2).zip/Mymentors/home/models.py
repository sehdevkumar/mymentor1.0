from django.db import models

# Create your models here.

class Tutorials(models.Model): 
	name = models.CharField(max_length=200,default='')
	channel_name = models.CharField(max_length=200,default='')
	title = models.CharField(max_length=1000,default='')
	profile_img = models.FileField(upload_to='profile_img/',default='')
	channel_profile = models.FileField(upload_to='channel_profile/',default='')
	about = models.TextField(max_length=1000000,default='')
	subscribers = models.CharField(max_length=1000,default='')
	channel_link = models.CharField(max_length=1000,default='')
	intro_video = models.CharField(max_length=1000,default='')
	tutorial_cate = models.CharField(max_length=1000,default='')



class DataStructue(models.Model):
	page = models.TextField(max_length=1000000000,default='')
	ds_cate = models.CharField(max_length=10000,default='')
	any_pic = models.FileField(upload_to='webpage/',default='')



